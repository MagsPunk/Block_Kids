//src/services/math_lesson_service.rs
#![no_std]

use sails_rs::prelude::*;
//use gstd::sync::{Arc, Mutex}; // Importar correctamente Arc y Mutex
use gstd::msg; // Importar el módulo msg
//use crate::states::MathLessonState;
use crate::states::math_lesson_state::{MathLessonState,initialize_state};


#[derive(Default)]
pub struct MathLessonService;

#[service]
impl MathLessonService {
    pub fn seed() {
        initialize_state();// Inicializa el estado si es necesario
    }

    pub fn new() -> Self {
        Self
    }

    pub fn get_exercise(&self) -> MathLessonEvent {
        let user_id = msg::source().into();
        if let Some((exercise, _)) = MathLessonState::get_current_exercise(&user_id) {
            MathLessonEvent::Exercise(exercise)
        } else {
            MathLessonEvent::Completed
        }
    }

    pub fn submit_answer(&mut self, answer: i32) -> MathLessonEvent {
        let user_id = msg::source().into();
        if MathLessonState::check_answer(&user_id, answer) {
            MathLessonState::next_exercise(&user_id);
            MathLessonEvent::CorrectAnswer
        } else {
            MathLessonEvent::WrongAnswer
        }
    }
}

#[derive(Encode, Decode, TypeInfo)]
#[codec(crate = sails_rs::scale_codec)]
#[scale_info(crate = sails_rs::scale_info)]
pub enum MathLessonEvent {
    Exercise(String),
    CorrectAnswer,
    WrongAnswer,
    Completed,
}
