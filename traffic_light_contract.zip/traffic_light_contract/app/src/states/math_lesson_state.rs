#![no_std]

use sails_rs::prelude::*;
//use gstd::sync::{Arc, Mutex}; // Importar correctamente Arc y Mutex
use gstd::collections::HashMap;

#[derive(Clone, Default)]
pub struct MathLessonState {
    current_exercise: u32,
    exercises: Vec<(String, i32)>,
    user_progress: HashMap<ActorId, u32>,
}

static mut STATE: Option<MathLessonState> = None;

impl MathLessonState {
    pub fn new() -> Self {
        Self {
            current_exercise: 0,
            exercises: vec![
                ("2 + 2".to_string(), 4),
                ("3 + 5".to_string(), 8),
                ("7 - 3".to_string(), 4),
            ],
            user_progress: HashMap::new(),
        }
    }

    pub fn get_current_exercise(user_id: &ActorId) -> Option<(String, i32)> {
        let state = unsafe { STATE.as_ref().unwrap() };
        let index = state.user_progress.get(user_id).copied().unwrap_or(0);
        state.exercises.get(index as usize).cloned()
    }

    pub fn next_exercise(user_id: &ActorId) {
        let mut state = unsafe { STATE.as_ref().unwrap() };
        let mut user_index = state.user_progress.clone().entry(*user_id).or_insert(0);
        //*user_index += 1;
    }

    pub fn check_answer(user_id: &ActorId, answer: i32) -> bool {
        if let Some((_, correct_answer)) = Self::get_current_exercise(user_id) {
            return answer == correct_answer;
        }
        false
    }
}

pub fn initialize_state() {
    unsafe {
        STATE = Some(MathLessonState::new());
    }
}
