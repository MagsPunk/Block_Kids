#![no_std]

use sails_rs::prelude::*;
use services::math_lesson_service::MathLessonService;
pub struct MathLessonProgram;

pub mod states;
pub mod services;

#[program]
impl MathLessonProgram {
    pub fn new() -> Self {
        MathLessonService::seed();
        Self
    }

    #[route("MathLesson")]
    pub fn math_lesson_svc(&self) -> MathLessonService {
        MathLessonService::new()
    }
}
