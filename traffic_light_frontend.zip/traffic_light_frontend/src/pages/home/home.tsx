
import { BlocKid } from "@/components/TrafficLightComponents/Block_kids/Block_kids";

export const Home = () => {
    return (
     <BlocKid />
        
    );
};