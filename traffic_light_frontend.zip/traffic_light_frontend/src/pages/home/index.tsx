import { Home } from "./home";

export{ Home };