import { WalletConnect } from './WalletConnect';

export { WalletConnect };
