import { useAccount, useAlert } from "@gear-js/react-hooks";
import { web3FromSource } from "@polkadot/extension-dapp";
import { ChakraProvider, Box, Button, VStack, Heading, Text, Icon, Input, useToast } from "@chakra-ui/react";
import { useState } from 'react';
import { useSailsCalls } from "@/app/hooks";


function BlocKid() {
  const [monedas, setMonedas] = useState(0);
  const sails = useSailsCalls();
  const alert = useAlert();
  const { accounts, account } = useAccount();
  const [inputValue, setInputValue] = useState('');
  const toast = useToast();

  // Función para manejar el cambio en el input
  const handleInputChange = async(e) => {
    const value = e.target.value;
    setInputValue(value);
    
    // Convertir a número y verificar si es 5
    if (parseInt(value)==4 ) {
      // Aquí puedes poner la acción que quieras que suceda
      await signer()
      toast({
        title: "¡Correcto!",
        description: "Has ingresado el número 4",
        status: "success",
        duration: 2000,
        isClosable: true,
      });
      // Ejemplo: aumentar monedas
      setMonedas(prev => prev + 1);
    }
    else{
      if(parseInt(value)>0){
      await signer()
      toast({
        title: "Incorrecto!",
        description: "Has ingresado el número incorrecto",
        status: "error",
        duration: 2000,
        isClosable: true,
      });}
    }
  }; // Se agregó esta llave faltante

  const signer = async () => {
    if (!accounts) {
      alert.error('Accounts is not ready');
      return;
    }

    const localaccount = account?.address;
    const isVisibleAccount = accounts.some(
      (visibleAccount) => visibleAccount.address === localaccount
    );

    if (isVisibleAccount) {
      if (!sails) {
        alert.error('sails is not ready');
        return;
      }

      if (!account || !accounts) {
        alert.error('Account is not ready');
        return;
      }

      const { signer } = await web3FromSource(accounts[0].meta.source);
     console.log(inputValue)
      const response = await sails.command(
        'MathLesson/SubmitAnswer',
        {
          userAddress: account.decodedAddress,
          signer
        },
        {
          callArguments:[inputValue],
          callbacks: {
            onLoad() { alert.info('Will send a message'); },
            onBlock(blockHash) { alert.success(`In block: ${blockHash}`); },
            onSuccess() { alert.success('Message send!'); },
            onError() { alert.error('Error while sending message'); }
          }
        }
      );

      console.log(response);
    } else {
      alert.error("Account not available to sign");
    }
  };

  return (
    <ChakraProvider>
      <Box
        bgImage="url('/src/components/TrafficLightComponents/Block_kids/img/fondo.jpg')"
        bgPosition="center"
        bgRepeat="no-repeat"
        bgSize="cover"
        w="100%"
        h="100vh"
      >
        {/* Botón con imagen */}
        <Button
          onClick={() => setMonedas(prev => prev + 1)}
          position="absolute"
          top="50%"
          left="50px"
          bg="transparent"
          _hover={{ bg: 'transparent' }}
        >
          <img
            src="/src/components/TrafficLightComponents/Block_kids/img/kid.png"
            alt="Marco"
            style={{ width: 400, height: 400, marginRight: 8 }}
          />
        </Button>
        <Button
          onClick={signer}
          position="absolute"
          top="65%"
          right="150px"
          bg="transparent"
          _hover={{ bg: 'transparent' }}
        >
          <img
            src="/src/components/TrafficLightComponents/Block_kids/img/librero.jpg"
            alt="Sumas"
            style={{ width: 200, height: 400, marginRight: 8 }}
          />
        </Button>
        <Button
          onClick={signer}
          position="absolute"
          top="120px"
          right="160px"
          bg="transparent"
          _hover={{ bg: 'transparent' }}
        >
          <img
            src="/src/components/TrafficLightComponents/Block_kids/img/moneda.png"
            alt="moneda"
            style={{ width: 100, height: 100, marginRight: 8 }}
          />
        </Button>
       
        <Text  position="absolute"
          top="45%"
          fontSize="3xl"
          right="50%"
          color="white" 
          fontWeight="bold">
          
          Cuanto es 2 + 2 ?
          </Text>
        <VStack
          position="absolute"
          top="50%"
          right="50%"
          spacing={2}
        >
          <Text color="white" fontWeight="bold">
            Ingresa un número:
          </Text>
          <Input
            type="number"
            value={inputValue}
            onChange={handleInputChange}
            placeholder="Ingresa un número"
            width="150px"
            bg="black"
            textAlign="center"
          />
        </VStack>
     
        <Text
          fontSize="24px"
          color="white"
          position="absolute"
          top="110px"
          right="30px"
        >
        Usuario:<br />
        Dinosaurio123 <br />
        <Text as="span" fontWeight="bold">Monedas:{monedas}</Text> 
        </Text>
      </Box>
    </ChakraProvider>
  );
}

export { BlocKid };