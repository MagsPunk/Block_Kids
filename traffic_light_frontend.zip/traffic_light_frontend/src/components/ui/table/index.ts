export { Table, TableBody, TableCell, TableFooter, TableCaption, TableHead, TableHeader, TableRow } from './table';
