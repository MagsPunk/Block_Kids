export { Heading, headingVariants } from './Heading';
export type { HeadingProps } from './Heading';
